//
//  Post.swift
//  Assignment
//
//  Created by Narra, Harish (C) (IN) on 24/05/24.
//

import Foundation

struct Post: Codable {
    let id: Int
    let title: String
    let body: String
}
