//
//  PostsDetaiViewController.swift
//  Assignment
//
//  Created by Narra, Harish (C) (IN) on 24/05/24.
//

import UIKit

class PostsDetaiViewController: UIViewController {
    
    var post: Post?
    
    @IBOutlet weak var myTitle: UILabel!
    @IBOutlet weak var myBody: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        myTitle.text = post?.title
        myBody.text = post?.body
    }
    
}
