//
//  PostsViewController.swift
//  Assignment
//
//  Created by Narra, Harish (C) (IN) on 24/05/24.
//

import UIKit

class PostsViewController: UIViewController {
    
    private var posts: [Post] = []
    private var currentPage = 1
    private let limit = 20
    private var isLoading = false
    
    @IBOutlet weak var tableView: UITableView!
    
    private var computationCache: [Int: String] = [:]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        loadPosts(page: currentPage)
    }
    
    private func loadPosts(page: Int) {
        guard !isLoading else { return }
        isLoading = true
        NetworkManager.shared.fetchPosts(page: page, limit: limit) { [weak self] result in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let posts):
                    self.posts.append(contentsOf: posts)
                    self.tableView.reloadData()
                case .failure(let error):
                    print("Failed to fetch posts:", error)
                }
            }
        }
    }
}

extension PostsViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return posts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PostsTableViewCell", for: indexPath) as! PostsTableViewCell
        let post = posts[indexPath.row]
        cell.title?.text = post.title
        
        if let cachedDetail = computationCache[post.id] {
            cell.detailTextLabel?.text = cachedDetail
        } else {
            DispatchQueue.global(qos: .background).async {
                let startTime = CFAbsoluteTimeGetCurrent()
                let computedDetail = self.heavyComputation(for: post)
                let timeElapsed = CFAbsoluteTimeGetCurrent() - startTime
                print("Time taken for computation: \(timeElapsed)")
                
                DispatchQueue.main.async {
                    self.computationCache[post.id] = computedDetail
                    cell.detailTextLabel?.text = computedDetail
                }
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if indexPath.row == posts.count - 1 {
            currentPage += 1
            loadPosts(page: currentPage)
        }
    }
    
    private func heavyComputation(for post: Post) -> String {
        // Simulate intensive computation
        return "Computed detail for post \(post.id)"
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "PostsDetaiViewController") as? PostsDetaiViewController
        vc?.post = posts[indexPath.row]
        self.navigationController?.pushViewController(vc!, animated: true)
    }
}
